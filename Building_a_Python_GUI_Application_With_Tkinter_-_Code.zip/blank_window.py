import tkinter as tk

window = tk.Tk()
frame = tk.Frame(master=window, width=200, height=200)
frame.pack()
window.mainloop()
